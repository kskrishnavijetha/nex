
import React from 'react';
import HistoryContainer from '@/components/history/HistoryContainer';

const History: React.FC = () => {
  return <HistoryContainer />;
};

export default History;

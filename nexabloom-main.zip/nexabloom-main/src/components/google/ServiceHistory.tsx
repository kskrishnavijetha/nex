
import React from 'react';
import { ServiceHistoryContainer } from './service-history';

const ServiceHistory: React.FC = () => {
  return <ServiceHistoryContainer />;
};

export default ServiceHistory;


export { createFindingsTable } from './createFindingsTable';


// Refactored - now using dedicated translations module
import { industriesTranslations } from './translations/industries';

// Re-export the industry translations to maintain backward compatibility
export const industryTranslations = industriesTranslations;

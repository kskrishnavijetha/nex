
// This file now acts as a bridge to maintain backward compatibility
// It re-exports everything from the new language module
export * from './language';
